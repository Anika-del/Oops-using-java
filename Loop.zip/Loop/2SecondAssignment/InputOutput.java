class InputOutput {
    public static void main(String[] args) {
        
       
        System.out.print("INPUT : " );
        int input = new java.util.Scanner(System.in).nextInt();
        System.out.println("OUTPUT : " +input);

        System.out.print("INPUT : " );
        int inputt = new java.util.Scanner(System.in).nextInt();
        System.out.println("OUTPUT : " +Math.abs(inputt));   
    }
    
}
