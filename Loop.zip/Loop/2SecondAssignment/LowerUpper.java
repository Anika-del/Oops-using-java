class LowerUpper {

    public static void main(String[] args) {
        
        for(char i='a'; i<='z'; i++){
            System.out.print(i+" ");
        }
            System.out.println(" ");

        for(char j='A'; j<='Z'; j++){
            System.out.print(j+" ");
        }
    }
    
}
