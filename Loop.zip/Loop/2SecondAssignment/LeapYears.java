class LeapYears {

   // If the year is divisible by 4,
    //If the year is divisible by 100,
   // If the year is divisible by 400, 
   //the year is a leap year.

   // If the year is not divisible by 100 or is divisible by 400, the year is a leap year.
   // the year is not a leap year.
    
}
