class ABCDE {

    public static void main(String[] args) {
    
      int no = 5;
    char ch = 'A' ;
    for(int i=1; i<=5; i++){
        for(int j=1; j<=5; j++){
            System.out.print(ch+" ");
             ch++;
           
        }
        System.out.println();
        no++;
    }
    
}
}