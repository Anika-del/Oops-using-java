/*
*****
22222
*****
44444
*****
*/
public class J {

    public static void main(String[] args) {
        
        for(int i=1; i<=5; i++){
            for(int j=1; j<=5; j++){
                
             if(i==2){
                System.out.print("2");
             }
           else if(i==4){
                System.out.print("4");
            }
             else{
                System.out.print("*");
             }
            }
                 System.out.println();
        }
      
    }
    }
