//  Higest common factor calculator 
class HCF {

    public static void main(String[] args) {
        
    }
    
}
