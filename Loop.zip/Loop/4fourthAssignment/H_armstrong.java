class H_armstrong {

    public static void main(String[] args) {
        
        
    }
    
}
