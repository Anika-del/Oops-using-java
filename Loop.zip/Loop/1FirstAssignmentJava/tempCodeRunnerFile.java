class OldYoung {

        public static void main(String[] args) {
    
        }}