class SqureOrNot {

    

        public static void main(String[] args) {
    
        System.out.println("Enter the length :");
        int l = new java.util.Scanner(System.in).nextInt();
         System.out.println("Enter the bridthth :");
        int b = new java.util.Scanner(System.in).nextInt();

        if(l==b)
        System.out.println("Yes It is Squire");
        else
        System.out.println("Yes It is not Squire");
    
          
    }
    
    
}
