class LowerGreater {

        public static void main(String[] args) {
    
        System.out.println("Enter the First no. :");
        int a = new java.util.Scanner(System.in).nextInt();
         System.out.println("Enter the second no. :");
        int b = new java.util.Scanner(System.in).nextInt();

        if(a>b)
        System.out.println("A is greatest");
        
        else
        System.out.println("B is greatest");
        
       
    
}

    
}
