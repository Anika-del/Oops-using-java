//take 2 number WAP to find the power of anither
class PowerOf {

    
    System.out.println("Enter no. ");
    int exponent = new java.util.Scanner(System.in).nextInt();

    int base;
    int power = 1;
    for(int i=1; i<=exponent; i++){
        power = power*base;
        
    }
    
    public static void main(String[] args) {
        
    }
}
