//1 to n table
class Table {

    public static void main(String[] args) {
       
        int n = 10;
        for(int i=1; i<=n; i++){
          System.out.println(i);
        }
      
    } 
}
