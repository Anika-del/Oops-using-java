public class L {


        public static void main(String[] args) {
            
           
          
        } 
    
}
